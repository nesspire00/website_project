function privacyAlert() {
    alert("All information provided by the user is used to privide a better experience for that particular user and is not disclosed without conscent.");
}